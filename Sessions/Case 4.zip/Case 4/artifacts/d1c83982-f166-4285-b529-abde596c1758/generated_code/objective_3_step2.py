# objective_3 step 2: Compare median minority_pct between hotspot and non-hotspot tracts using Kruskal-Wallis H-test
# status: skipped
# recorded error: Skipped: input(s) ['risk_hotspots.gpkg'] from failed/empty step

